package com.example.chowall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChowallApplicationTests {

    @Test
    void contextLoads() {
    }

}
