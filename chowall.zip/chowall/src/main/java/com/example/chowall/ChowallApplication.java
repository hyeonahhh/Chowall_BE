package com.example.chowall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChowallApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChowallApplication.class, args);
    }

}
